package com.example.flashcardquizapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private TextView tvPosition, tvQuestion, tvAnswer;
    private LinearLayout answerContainer;
    private MaterialButton btnPrev, btnToggle, btnNext;
    private FloatingActionButton fabManage;

    private List<Flashcard> cards;
    private int index = 0;
    private boolean showingAnswer = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        tvPosition = findViewById(R.id.tvPosition);
        tvQuestion = findViewById(R.id.tvQuestion);
        tvAnswer = findViewById(R.id.tvAnswer);
        answerContainer = findViewById(R.id.answerContainer);
        btnPrev = findViewById(R.id.btnPrev);
        btnToggle = findViewById(R.id.btnToggle);
        btnNext = findViewById(R.id.btnNext);
        fabManage = findViewById(R.id.fabManage);

        // Load data
        loadData();

        // Wire buttons
        btnPrev.setOnClickListener(v -> {
            if (cards.isEmpty()) return;
            index = (index - 1 + cards.size()) % cards.size();
            showingAnswer = false;
            render();
        });

        btnNext.setOnClickListener(v -> {
            if (cards.isEmpty()) return;
            index = (index + 1) % cards.size();
            showingAnswer = false;
            render();
        });

        btnToggle.setOnClickListener(v -> {
            if (cards.isEmpty()) return;
            showingAnswer = !showingAnswer;
            render();
        });

        // Tap question to toggle
        tvQuestion.setOnClickListener(v -> {
            if (cards.isEmpty()) return;
            showingAnswer = !showingAnswer;
            render();
        });

        // Open manage screen
        fabManage.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, ManageCardsActivity.class)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Refresh list in case user changed cards
        loadData();
    }

    private void loadData() {
        cards = FlashcardStore.load(this);
        if (cards.isEmpty()) {
            // Seed sample cards (only first-run)
            cards.add(new Flashcard("What is the capital of France?", "Paris"));
            cards.add(new Flashcard("Android layout files are written in?", "XML"));
            cards.add(new Flashcard("Java key-value collection class?", "HashMap"));
            FlashcardStore.save(this, cards);
        }
        if (index >= cards.size()) index = 0;
        showingAnswer = false;
        render();
    }

    private void render() {
        boolean has = !cards.isEmpty();

        btnPrev.setEnabled(has);
        btnNext.setEnabled(has);
        btnToggle.setEnabled(has);
        fabManage.setEnabled(true);

        if (!has) {
            tvPosition.setText("0/0");
            tvQuestion.setText("No cards. Add some via the + button.");
            answerContainer.setVisibility(View.GONE);
            btnToggle.setText("Show Answer");
            return;
        }

        tvPosition.setText((index + 1) + "/" + cards.size());
        Flashcard fc = cards.get(index);
        tvQuestion.setText(fc.getQuestion());
        tvAnswer.setText(fc.getAnswer());

        answerContainer.setVisibility(showingAnswer ? View.VISIBLE : View.GONE);
        btnToggle.setText(showingAnswer ? "Hide Answer" : "Show Answer");
    }
}

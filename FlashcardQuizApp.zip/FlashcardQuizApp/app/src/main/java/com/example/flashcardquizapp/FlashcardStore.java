package com.example.flashcardquizapp;


import android.content.Context;
import android.content.SharedPreferences;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class FlashcardStore {
    private static final String PREF = "flashcards_pref";
    private static final String KEY  = "cards_json";

    public static List<Flashcard> load(Context ctx) {
        SharedPreferences sp = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        String json = sp.getString(KEY, null);
        if (json == null) return new ArrayList<>();
        Type type = new TypeToken<List<Flashcard>>(){}.getType();
        try {
            return new Gson().fromJson(json, type);
        } catch (Exception e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    public static void save(Context ctx, List<Flashcard> list) {
        SharedPreferences sp = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        sp.edit().putString(KEY, new Gson().toJson(list)).apply();
    }
}

package com.example.flashcardquizapp;



import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class FlashcardAdapter extends RecyclerView.Adapter<FlashcardAdapter.Holder> {

    public interface OnItemClick { void onClick(int position); }

    private final List<Flashcard> data = new ArrayList<>();
    private final OnItemClick listener;

    public FlashcardAdapter(List<Flashcard> initial, OnItemClick listener) {
        if (initial != null) data.addAll(initial);
        this.listener = listener;
    }

    public void update(List<Flashcard> newData) {
        data.clear();
        if (newData != null) data.addAll(newData);
        notifyDataSetChanged();
    }

    @NonNull @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_flashcard, parent, false);
        return new Holder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull Holder h, int position) {
        Flashcard f = data.get(position);
        h.tvQ.setText(f.getQuestion());
        h.tvA.setText(f.getAnswer());
        h.itemView.setOnClickListener(v -> {
            if (listener != null) listener.onClick(h.getAdapterPosition());
        });
    }

    @Override
    public int getItemCount() { return data.size(); }

    static class Holder extends RecyclerView.ViewHolder {
        TextView tvQ, tvA;
        Holder(@NonNull View itemView) {
            super(itemView);
            tvQ = itemView.findViewById(R.id.tvQ);
            tvA = itemView.findViewById(R.id.tvA);
        }
    }
}

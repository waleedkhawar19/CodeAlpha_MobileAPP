package com.example.flashcardquizapp;



import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;

import java.util.List;

public class AddEditFlashcardActivity extends AppCompatActivity {

    private EditText etQuestion, etAnswer;
    private int editIndex = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_flashcard);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());

        etQuestion = findViewById(R.id.etQuestion);
        etAnswer = findViewById(R.id.etAnswer);
        MaterialButton btnSave = findViewById(R.id.btnSave);

        editIndex = getIntent().getIntExtra("index", -1);
        if (editIndex >= 0) {
            List<Flashcard> list = FlashcardStore.load(this);
            if (editIndex < list.size()) {
                Flashcard fc = list.get(editIndex);
                etQuestion.setText(fc.getQuestion());
                etAnswer.setText(fc.getAnswer());
                toolbar.setTitle("Edit Card");
            } else {
                editIndex = -1;
            }
        } else {
            toolbar.setTitle("Add Card");
        }

        btnSave.setOnClickListener(v -> {
            String q = etQuestion.getText().toString().trim();
            String a = etAnswer.getText().toString().trim();
            if (q.isEmpty() || a.isEmpty()) {
                if (q.isEmpty()) etQuestion.setError("Required");
                if (a.isEmpty()) etAnswer.setError("Required");
                Toast.makeText(this, "Please enter both question and answer.", Toast.LENGTH_SHORT).show();
                return;
            }

            List<Flashcard> list = FlashcardStore.load(this);
            if (editIndex >= 0) {
                if (editIndex < list.size()) {
                    list.set(editIndex, new Flashcard(q, a));
                } else {
                    list.add(new Flashcard(q, a));
                }
            } else {
                list.add(new Flashcard(q, a));
            }
            FlashcardStore.save(this, list);
            finish();
        });
    }
}

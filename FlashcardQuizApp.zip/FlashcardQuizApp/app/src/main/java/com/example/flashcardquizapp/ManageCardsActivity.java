package com.example.flashcardquizapp;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class ManageCardsActivity extends AppCompatActivity {

    private RecyclerView recycler;
    private FlashcardAdapter adapter;
    private FloatingActionButton fabAdd;
    private TextView emptyView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_cards);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());

        recycler = findViewById(R.id.recycler);
        // Use 2 columns grid for a nicer tile layout
        recycler.setLayoutManager(new GridLayoutManager(this, 2));

        adapter = new FlashcardAdapter(FlashcardStore.load(this), position -> {
            Intent i = new Intent(ManageCardsActivity.this, AddEditFlashcardActivity.class);
            i.putExtra("index", position);
            startActivity(i);
        });
        recycler.setAdapter(adapter);

        fabAdd = findViewById(R.id.fabAdd);
        fabAdd.setOnClickListener(v -> startActivity(new Intent(ManageCardsActivity.this, AddEditFlashcardActivity.class)));

        // Empty placeholder (added programmatically)
        emptyView = new TextView(this);
        emptyView.setText("No cards yet.\nTap + to add a flashcard.");
        emptyView.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        emptyView.setPadding(40, 40, 40, 40);
        emptyView.setTextSize(16f);

        // Swipe to delete
        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override public boolean onMove(RecyclerView rv, RecyclerView.ViewHolder vh, RecyclerView.ViewHolder tgt) { return false; }
            @Override public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction) {
                int pos = viewHolder.getAdapterPosition();
                List<Flashcard> list = FlashcardStore.load(ManageCardsActivity.this);
                if (pos >= 0 && pos < list.size()) {
                    list.remove(pos);
                    FlashcardStore.save(ManageCardsActivity.this, list);
                    adapter.update(list);
                    checkEmpty();
                }
            }
        }).attachToRecyclerView(recycler);
    }

    @Override
    protected void onResume() {
        super.onResume();
        adapter.update(FlashcardStore.load(this));
        checkEmpty();
    }

    private void checkEmpty() {
        if (adapter.getItemCount() == 0) {
            // Add emptyView to the parent of recycler if not already added
            ViewGroup parent = (ViewGroup) recycler.getParent();
            if (emptyView.getParent() == null) {
                parent.addView(emptyView);
            }
            recycler.setVisibility(View.GONE);
        } else {
            // Remove emptyView if present and show recycler
            ViewGroup parent = (ViewGroup) recycler.getParent();
            if (emptyView.getParent() != null) {
                parent.removeView(emptyView);
            }
            recycler.setVisibility(View.VISIBLE);
        }
    }
}

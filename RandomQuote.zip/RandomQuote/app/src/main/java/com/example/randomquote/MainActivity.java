package com.example.randomquote;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private TextView tvQuote, tvAuthor;
    private MaterialButton btnNewQuote;

    private final List<Quote> quotes = new ArrayList<>();
    private final Random random = new Random();
    private int currentIndex = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        tvQuote = findViewById(R.id.tvQuote);
        tvAuthor = findViewById(R.id.tvAuthor);
        btnNewQuote = findViewById(R.id.btnNewQuote);

        seedQuotes();
        showRandomQuote();

        btnNewQuote.setOnClickListener(v -> showRandomQuote());
    }

    private void showRandomQuote() {
        if (quotes.isEmpty()) return;

        int nextIndex;
        if (quotes.size() == 1) {
            nextIndex = 0;
        } else {
            // avoid immediate repeat
            do {
                nextIndex = random.nextInt(quotes.size());
            } while (nextIndex == currentIndex);
        }
        currentIndex = nextIndex;

        Quote q = quotes.get(currentIndex);
        tvQuote.setText("“" + q.text + "”");
        tvAuthor.setText("— " + q.author);
    }

    private void seedQuotes() {
        // Add or replace these with your favorite quotes
        quotes.add(new Quote("The only way to do great work is to love what you do.", "Steve Jobs"));
        quotes.add(new Quote("In the middle of difficulty lies opportunity.", "Albert Einstein"));
        quotes.add(new Quote("Whether you think you can or you think you can’t, you’re right.", "Henry Ford"));
        quotes.add(new Quote("It always seems impossible until it’s done.", "Nelson Mandela"));
        quotes.add(new Quote("Simplicity is the ultimate sophistication.", "Leonardo da Vinci"));
        quotes.add(new Quote("The secret of getting ahead is getting started.", "Mark Twain"));
        quotes.add(new Quote("If you’re going through hell, keep going.", "Winston Churchill"));
        // ... add more if you like
    }

    static class Quote {
        final String text;
        final String author;
        Quote(String text, String author) { this.text = text; this.author = author; }
    }
}
